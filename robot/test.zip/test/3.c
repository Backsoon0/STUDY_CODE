#include<stdio.h>

int main()
{
char a[]="abc";
char *str="abc";
a[2]='v';
str[2]='m';
str="hello";
return 0;
}

